<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('pages.userentry');
});

Route::get('question','MyCreateController@choices');
Route::POST('submit','MyCreateController@store');
Route::POST('submitt','MyCreateController@create_user');
Route::get('view/{$users}','MyCreateController@view');


<form action = "submit" method = "post" id="1" >

<?php echo e(csrf_field()); ?>


            <p><?php echo e($question1->questions); ?></p>
            <input hidden type = "number" name = "qid" value = "<?php echo e($question1->id); ?>">
            <input hidden type = "text" name = "name" value = "<?php echo e($users->name); ?>">
            <input hidden type = "text" name = "user_id" value = "<?php echo e($users->id); ?>">
           <input type="radio" id="optiona" name="optiona" value="<?php echo e($question1->optiona); ?>">
           <label for="radio"><?php echo e($question1->optiona); ?></label><br>
          <input type="radio" id="optionb" name="optionb" value="<?php echo e($question1->optionb); ?>">
          <label for="female"><?php echo e($question1->optionb); ?></label><br>
          <input type="radio" id="optionc" name="optionc" value="<?php echo e($question1->optionc); ?>">
          <label for="other"><?php echo e($question1->optionc); ?></label><br>
          <input type="radio" id="optiond" name="optiond" value="<?php echo e($question1->optiond); ?>">
         <label for="other"><?php echo e($question1->optiond); ?></label><br>
         <input type = "submit" value = "submit">
  
       </form>
       <form action = "submit" method = "post">

<?php echo e(csrf_field()); ?>


            <p><?php echo e($question2->questions); ?></p>
            <input hidden type = "number" name = "qid" value = "<?php echo e($question2->id); ?>">
            <input hidden type = "text" name = "name" value = "<?php echo e($users->name); ?>">
            <input hidden type = "text" name = "user_id" value = "<?php echo e($users->id); ?>">
           <input type="radio" id="optiona" name="optiona" value="<?php echo e($question2->optiona); ?>">
           <label for="radio"><?php echo e($question2->optiona); ?></label><br>
          <input type="radio" id="optionb" name="optionb" value="<?php echo e($question2->optionb); ?>">
          <label for="female"><?php echo e($question2->optionb); ?></label><br>
          <input type="radio" id="optionc" name="optionc" value="<?php echo e($question2->optionc); ?>">
          <label for="other"><?php echo e($question2->optionc); ?></label><br>
          <input type="radio" id="optiond" name="optiond" value="<?php echo e($question2->optiond); ?>">
         <label for="other"><?php echo e($question2->optiond); ?></label><br>
         <input type = "submit" value = "submit">
  
       </form>
       <form action = "submit" method = "post">

       <?php echo e(csrf_field()); ?>


            <p><?php echo e($question3->questions); ?></p>
            <input hidden type = "number" name = "qid" value = "<?php echo e($question3->id); ?>">
            <input hidden type = "text" name = "name" value = "<?php echo e($users->name); ?>">
            <input hidden type = "text" name = "user_id" value = "<?php echo e($users->id); ?>">
           <input type="radio" id="optiona" name="optiona" value="<?php echo e($question3->optiona); ?>">
           <label for="radio"><?php echo e($question3->optiona); ?></label><br>
          <input type="radio" id="optionb" name="optionb" value="<?php echo e($question3->optionb); ?>">
          <label for="female"><?php echo e($question3->optionb); ?></label><br>
          <input type="radio" id="optionc" name="optionc" value="<?php echo e($question3->optionc); ?>">
          <label for="other"><?php echo e($question3->optionc); ?></label><br>
          <input type="radio" id="optiond" name="optiond" value="<?php echo e($question3->optiond); ?>">
         <label for="other"><?php echo e($question3->optiond); ?></label><br>
         <input type = "submit" value = "submit">
  
       </form>
       <form action = "submit" method = "post">

       <?php echo e(csrf_field()); ?>


            <p><?php echo e($question4->questions); ?></p>
            <input hidden type = "number" name = "qid" value = "<?php echo e($question4->id); ?>">
            <input hidden type = "text" name = "name" value = "<?php echo e($users->name); ?>">
            <input hidden type = "text" name = "user_id" value = "<?php echo e($users->id); ?>">
           <input type="radio" id="optiona" name="optiona" value="<?php echo e($question4->optiona); ?>">
           <label for="radio"><?php echo e($question4->optiona); ?></label><br>
          <input type="radio" id="optionb" name="optionb" value="<?php echo e($question4->optionb); ?>">
          <label for="female"><?php echo e($question4->optionb); ?></label><br>
          <input type="radio" id="optionc" name="optionc" value="<?php echo e($question4->optionc); ?>">
          <label for="other"><?php echo e($question4->optionc); ?></label><br>
          <input type="radio" id="optiond" name="optiond" value="<?php echo e($question4->optiond); ?>">
         <label for="other"><?php echo e($question4->optiond); ?></label><br>
         <input type = "submit" value = "submit">
  
       </form>
       <form action = "submit" method = "post">

       <?php echo e(csrf_field()); ?>


            <p><?php echo e($question5->question); ?></p>
            <input hidden type = "number" name = "qid" value = "<?php echo e($question5->id); ?>">
            <input hidden type = "text" name = "name" value = "<?php echo e($users->name); ?>">
            <input hidden type = "text" name = "user_id" value = "<?php echo e($users->id); ?>">
           <input type="radio" id="optiona" name="optiona" value="<?php echo e($question5->optiona); ?>">
           <label for="radio"><?php echo e($question5->optiona); ?></label><br>
          <input type="radio" id="optionb" name="optionb" value="<?php echo e($question5->optionb); ?>">
          <label for="female"><?php echo e($question5->optionb); ?></label><br>
          <input type="radio" id="optionc" name="optionc" value="<?php echo e($question5->optionc); ?>">
          <label for="other"><?php echo e($question5->optionc); ?></label><br>
          <input type="radio" id="optiond" name="optiond" value="<?php echo e($question5->optiond); ?>">
         <label for="other"><?php echo e($question5->optiond); ?></label><br>
         <input type = "submit" value = "submit">
  
       </form>
       <form action = "submit" method = "post">

       <?php echo e(csrf_field()); ?>


            <p><?php echo e($question6->question); ?></p>
            <input hidden type = "number" name = "qid" value = "<?php echo e($question6->id); ?>">
            <input hidden type = "text" name = "name" value = "<?php echo e($users->name); ?>">
            <input hidden type = "text" name = "user_id" value = "<?php echo e($users->id); ?>">
           <input type="radio" id="optiona" name="optiona" value="<?php echo e($question6->optiona); ?>">
           <label for="radio"><?php echo e($question6->optiona); ?></label><br>
          <input type="radio" id="optionb" name="optionb" value="<?php echo e($question6->optionb); ?>">
          <label for="female"><?php echo e($question6->optionb); ?></label><br>
          <input type="radio" id="optionc" name="optionc" value="<?php echo e($question6->optionc); ?>">
          <label for="other"><?php echo e($question6->optionc); ?></label><br>
          <input type="radio" id="optiond" name="optiond" value="<?php echo e($question6->optiond); ?>">
         <label for="other"><?php echo e($question6->optiond); ?></label><br>
         <input type = "submit" value = "submit">
  
       </form>
       <form action = "submit" method = "post">

       <?php echo e(csrf_field()); ?>



            <p><?php echo e($question7->question); ?></p>
            <input hidden type = "number" name = "qid" value = "<?php echo e($question7->id); ?>">
            <input hidden type = "text" name = "name" value = "<?php echo e($users->name); ?>">
            <input hidden type = "text" name = "user_id" value = "<?php echo e($users->id); ?>">
           <input type="radio" id="optiona" name="optiona" value="<?php echo e($question7->optiona); ?>">
           <label for="radio"><?php echo e($question7->optiona); ?></label><br>
          <input type="radio" id="optionb" name="optionb" value="<?php echo e($question7->optionb); ?>">
          <label for="female"><?php echo e($question7->optionb); ?></label><br>
          <input type="radio" id="optionc" name="optionc" value="<?php echo e($question7->optionc); ?>">
          <label for="other"><?php echo e($question7->optionc); ?></label><br>
          <input type="radio" id="optiond" name="optiond" value="<?php echo e($question7->optiond); ?>">
         <label for="other"><?php echo e($question7->optiond); ?></label><br>
         <input type = "submit" value = "submit">
  
       </form>
       <form action = "submit" method = "post">

       <?php echo e(csrf_field()); ?>


            <p><?php echo e($question8->questions); ?></p>
            <input hidden type = "number" name = "qid" value = "<?php echo e($question8->id); ?>">
            <input hidden type = "text" name = "name" value = "<?php echo e($users->name); ?>">
            <input hidden type = "text" name = "user_id" value = "<?php echo e($users->id); ?>">
           <input type="radio" id="optiona" name="optiona" value="<?php echo e($question8->optiona); ?>">
           <label for="radio"><?php echo e($question8->optiona); ?></label><br>
          <input type="radio" id="optionb" name="optionb" value="<?php echo e($question8->optionb); ?>">
          <label for="female"><?php echo e($question8->optionb); ?></label><br>
          <input type="radio" id="optionc" name="optionc" value="<?php echo e($question8->optionc); ?>">
          <label for="other"><?php echo e($question8->optionc); ?></label><br>
          <input type="radio" id="optiond" name="optiond" value="<?php echo e($question8->optiond); ?>">
         <label for="other"><?php echo e($question8->optiond); ?></label><br>
         <input type = "submit" value = "submit">
  
     
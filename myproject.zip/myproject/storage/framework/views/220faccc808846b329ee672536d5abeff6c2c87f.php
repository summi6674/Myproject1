<h3>Your Name:<?php echo e($user_name); ?></h3>

<?php $__currentLoopData = $your_answer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<h5><?php echo e($user->questions); ?></h5>
<?php if($user->optiona!="Null"): ?>
<p><?php echo e($user->optiona); ?></p>
<?php endif; ?>
<?php if($user->optionb!="Null"): ?>
<p><?php echo e($user->optionb); ?></p>
<?php endif; ?>
<?php if($user->optionc!="Null"): ?>
<p><?php echo e($user->optionc); ?></p>
<?php endif; ?>
<?php if($user->optiond!="Null"): ?>
<p><?php echo e($user->optiond); ?></p>
<?php endif; ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
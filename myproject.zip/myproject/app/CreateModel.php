<?php

namespace App;


use Illuminate\Database\Eloquent\Model;

class CreateModel extends Model
{
    public $table = "submitted_answers";

    protected $fillable = [
       'name','qid', 'optiona', 'optionb', 'optionc','optiond',
    ];
}

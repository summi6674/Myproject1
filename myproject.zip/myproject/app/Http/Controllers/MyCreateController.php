<?php

namespace App\Http\Controllers;
use DB;
use Illuminate\Support\Facades\Hash;
use App\User;


use Illuminate\Http\Request;

class MyCreateController extends Controller
{
    //
    public function create_user(request $request){
        $users = new \App\UserModel();
        $users->name=$request->user;
        $users->save();
        // dd($user->name);
        $question1 = \App\question_table::select('*')->where('id',1)->first();
        // dd($question1);
        $question2 = \App\question_table::select('*')->where('id',2)->first();
        $question3 = \App\question_table::select('*')->where('id',3)->first();
        $question4 = \App\question_table::select('*')->where('id',4)->first();
        $question5 = \App\question_table::select('*')->where('id',5)->first();
        $question6 = \App\question_table::select('*')->where('id',6)->first();
        $question7 = \App\question_table::select('*')->where('id',7)->first();
        $question8 = \App\question_table::select('*')->where('id',8)->first();
        $question9 = \App\question_table::select('*')->where('id',9)->first();
        $question10 = \App\question_table::select('*')->where('id',10)->first();        // dd($question);
        return view('pages.create_question',compact('users','question1','question2','question3','question4','question5','question6','question7','question8','question9','question10'));

    }
    public function choices(){
        // echo "SUMIT";
        $users = DB::select('select * from newquestions');
        // echo "sumit";
        return view('pages.create_question',['users'=>$users]);
        // echo "sumit";
    }
    
    public function store(request $request)
    {
        // dd($request->all());
        // echo "sumit";
        $users = new \App\CreateModel();
        // echo "sumit";
        $users->qid =$request->qid;
        $users->name = $request->name;
        $users->user_id = $request->user_id;
   if ($request->optiona!=null){
    $users->optiona = $request->optiona;

   }
   else{
    $users->optiona ="Null";

   }
   if ($request->optionb!=null){
    $users->optionb = $request->optionb;

   }
   else{
    $users->optionb ="Null";

   }
   if ($request->optionc!=null){
    $users->optionc = $request->optionc;

   }
   else{
    $users->optionc ="Null";

   }
   if ($request->optiond!=null){
    $users->optiond = $request->optiond;

   }
   else{
    $users->optiond ="Null";

   }
        // $locations->optionb = $request->optionb;
        // $locations->optionc = $request->optionc;
        // $locations->optiond = $request->optiond;
        $users->save();
//    echo "sumit";
    // dd($users);
    $users->id=$users->user_id;
    // dd($users);
    // CreateModel::create($request->all());
    // return ('data inserted');
    $user_name=$request->name;
    $your_answer=\App\CreateModel::select('submitted_answers.*','newquestions.questions')
    ->leftJoin('newquestions','newquestions.id','=','submitted_answers.qid')
    ->where('user_id',$request->user_id)->get();
    // dd($your_answer);
    return view('pages.showanswer',compact('your_answer','user_name'));
    }
    public function view(request $request){
                // dd($request->all());
        return view('pages.showanswer');
    }
}

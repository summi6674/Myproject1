<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserModel extends Model
{
    //
    public $table = "users_data";

    protected $fillable = [
       'name',
    ];
}

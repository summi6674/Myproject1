<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class question_table extends Model
{
    //
    public $table = "newquestions";
}

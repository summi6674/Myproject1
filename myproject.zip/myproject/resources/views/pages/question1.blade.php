<p></p>

<input hidden type = "number" name = "qid" value = "{{$user->id }}">
  <input type="radio" id="optiona" name="optiona" value="{{$user->optiona}}">
  <label for="radio">{{$user->optiona}}</label><br>
  <input type="radio" id="optionb" name="optionb" value="{{$user->optionb}}">
  <label for="female">{{$user->optionb}}</label><br>
  <input type="radio" id="optionc" name="optionc" value="{{$user->optionc}}">
  <label for="other">{{$user->optionc}}</label><br>
  <input type="radio" id="optiond" name="optiond" value="{{$user->optiond}}">
  <label for="other">{{$user->optiond}}</label><br>
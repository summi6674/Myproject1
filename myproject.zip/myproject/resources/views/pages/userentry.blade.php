<form action = "submitt" method = "post">
{{ csrf_field() }}
<p>What is your name</p><br>
<input type = "text" name = "user" required>
<input type = "submit" value = "enter">
</form>


<form action = "submit" method = "post" id="1" >

{{ csrf_field() }}

            <p>{{$question1->questions }}</p>
            <input hidden type = "number" name = "qid" value = "{{$question1->id }}">
            <input hidden type = "text" name = "name" value = "{{$users->name }}">
            <input hidden type = "text" name = "user_id" value = "{{$users->id }}">
           <input type="radio" id="optiona" name="optiona" value="{{$question1->optiona}}">
           <label for="radio">{{$question1->optiona}}</label><br>
          <input type="radio" id="optionb" name="optionb" value="{{$question1->optionb}}">
          <label for="female">{{$question1->optionb}}</label><br>
          <input type="radio" id="optionc" name="optionc" value="{{$question1->optionc}}">
          <label for="other">{{$question1->optionc}}</label><br>
          <input type="radio" id="optiond" name="optiond" value="{{$question1->optiond}}">
         <label for="other">{{$question1->optiond}}</label><br>
         <input type = "submit" value = "submit">
  
       </form>
       <form action = "submit" method = "post">

{{ csrf_field() }}

            <p>{{$question2->questions }}</p>
            <input hidden type = "number" name = "qid" value = "{{$question2->id }}">
            <input hidden type = "text" name = "name" value = "{{$users->name }}">
            <input hidden type = "text" name = "user_id" value = "{{$users->id }}">
           <input type="radio" id="optiona" name="optiona" value="{{$question2->optiona}}">
           <label for="radio">{{$question2->optiona}}</label><br>
          <input type="radio" id="optionb" name="optionb" value="{{$question2->optionb}}">
          <label for="female">{{$question2->optionb}}</label><br>
          <input type="radio" id="optionc" name="optionc" value="{{$question2->optionc}}">
          <label for="other">{{$question2->optionc}}</label><br>
          <input type="radio" id="optiond" name="optiond" value="{{$question2->optiond}}">
         <label for="other">{{$question2->optiond}}</label><br>
         <input type = "submit" value = "submit">
  
       </form>
       <form action = "submit" method = "post">

       {{ csrf_field() }}

            <p>{{$question3->questions }}</p>
            <input hidden type = "number" name = "qid" value = "{{$question3->id }}">
            <input hidden type = "text" name = "name" value = "{{$users->name }}">
            <input hidden type = "text" name = "user_id" value = "{{$users->id }}">
           <input type="radio" id="optiona" name="optiona" value="{{$question3->optiona}}">
           <label for="radio">{{$question3->optiona}}</label><br>
          <input type="radio" id="optionb" name="optionb" value="{{$question3->optionb}}">
          <label for="female">{{$question3->optionb}}</label><br>
          <input type="radio" id="optionc" name="optionc" value="{{$question3->optionc}}">
          <label for="other">{{$question3->optionc}}</label><br>
          <input type="radio" id="optiond" name="optiond" value="{{$question3->optiond}}">
         <label for="other">{{$question3->optiond}}</label><br>
         <input type = "submit" value = "submit">
  
       </form>
       <form action = "submit" method = "post">

       {{ csrf_field() }}

            <p>{{$question4->questions }}</p>
            <input hidden type = "number" name = "qid" value = "{{$question4->id }}">
            <input hidden type = "text" name = "name" value = "{{$users->name }}">
            <input hidden type = "text" name = "user_id" value = "{{$users->id }}">
           <input type="radio" id="optiona" name="optiona" value="{{$question4->optiona}}">
           <label for="radio">{{$question4->optiona}}</label><br>
          <input type="radio" id="optionb" name="optionb" value="{{$question4->optionb}}">
          <label for="female">{{$question4->optionb}}</label><br>
          <input type="radio" id="optionc" name="optionc" value="{{$question4->optionc}}">
          <label for="other">{{$question4->optionc}}</label><br>
          <input type="radio" id="optiond" name="optiond" value="{{$question4->optiond}}">
         <label for="other">{{$question4->optiond}}</label><br>
         <input type = "submit" value = "submit">
  
       </form>
       <form action = "submit" method = "post">

       {{ csrf_field() }}

            <p>{{$question5->question }}</p>
            <input hidden type = "number" name = "qid" value = "{{$question5->id }}">
            <input hidden type = "text" name = "name" value = "{{$users->name }}">
            <input hidden type = "text" name = "user_id" value = "{{$users->id }}">
           <input type="radio" id="optiona" name="optiona" value="{{$question5->optiona}}">
           <label for="radio">{{$question5->optiona}}</label><br>
          <input type="radio" id="optionb" name="optionb" value="{{$question5->optionb}}">
          <label for="female">{{$question5->optionb}}</label><br>
          <input type="radio" id="optionc" name="optionc" value="{{$question5->optionc}}">
          <label for="other">{{$question5->optionc}}</label><br>
          <input type="radio" id="optiond" name="optiond" value="{{$question5->optiond}}">
         <label for="other">{{$question5->optiond}}</label><br>
         <input type = "submit" value = "submit">
  
       </form>
       <form action = "submit" method = "post">

       {{ csrf_field() }}

            <p>{{$question6->question }}</p>
            <input hidden type = "number" name = "qid" value = "{{$question6->id }}">
            <input hidden type = "text" name = "name" value = "{{$users->name }}">
            <input hidden type = "text" name = "user_id" value = "{{$users->id }}">
           <input type="radio" id="optiona" name="optiona" value="{{$question6->optiona}}">
           <label for="radio">{{$question6->optiona}}</label><br>
          <input type="radio" id="optionb" name="optionb" value="{{$question6->optionb}}">
          <label for="female">{{$question6->optionb}}</label><br>
          <input type="radio" id="optionc" name="optionc" value="{{$question6->optionc}}">
          <label for="other">{{$question6->optionc}}</label><br>
          <input type="radio" id="optiond" name="optiond" value="{{$question6->optiond}}">
         <label for="other">{{$question6->optiond}}</label><br>
         <input type = "submit" value = "submit">
  
       </form>
       <form action = "submit" method = "post">

       {{ csrf_field() }}


            <p>{{$question7->question }}</p>
            <input hidden type = "number" name = "qid" value = "{{$question7->id }}">
            <input hidden type = "text" name = "name" value = "{{$users->name }}">
            <input hidden type = "text" name = "user_id" value = "{{$users->id }}">
           <input type="radio" id="optiona" name="optiona" value="{{$question7->optiona}}">
           <label for="radio">{{$question7->optiona}}</label><br>
          <input type="radio" id="optionb" name="optionb" value="{{$question7->optionb}}">
          <label for="female">{{$question7->optionb}}</label><br>
          <input type="radio" id="optionc" name="optionc" value="{{$question7->optionc}}">
          <label for="other">{{$question7->optionc}}</label><br>
          <input type="radio" id="optiond" name="optiond" value="{{$question7->optiond}}">
         <label for="other">{{$question7->optiond}}</label><br>
         <input type = "submit" value = "submit">
  
       </form>
       <form action = "submit" method = "post">

       {{ csrf_field() }}

            <p>{{$question8->questions }}</p>
            <input hidden type = "number" name = "qid" value = "{{$question8->id }}">
            <input hidden type = "text" name = "name" value = "{{$users->name }}">
            <input hidden type = "text" name = "user_id" value = "{{$users->id }}">
           <input type="radio" id="optiona" name="optiona" value="{{$question8->optiona}}">
           <label for="radio">{{$question8->optiona}}</label><br>
          <input type="radio" id="optionb" name="optionb" value="{{$question8->optionb}}">
          <label for="female">{{$question8->optionb}}</label><br>
          <input type="radio" id="optionc" name="optionc" value="{{$question8->optionc}}">
          <label for="other">{{$question8->optionc}}</label><br>
          <input type="radio" id="optiond" name="optiond" value="{{$question8->optiond}}">
         <label for="other">{{$question8->optiond}}</label><br>
         <input type = "submit" value = "submit">
  
     
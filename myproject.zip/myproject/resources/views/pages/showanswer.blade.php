<h3>Your Name:{{$user_name}}</h3>

@foreach($your_answer as $user)
<h5>{{$user->questions}}</h5>
@if($user->optiona!="Null")
<p>{{$user->optiona}}</p>
@endif
@if($user->optionb!="Null")
<p>{{$user->optionb}}</p>
@endif
@if($user->optionc!="Null")
<p>{{$user->optionc}}</p>
@endif
@if($user->optiond!="Null")
<p>{{$user->optiond}}</p>
@endif

@endforeach